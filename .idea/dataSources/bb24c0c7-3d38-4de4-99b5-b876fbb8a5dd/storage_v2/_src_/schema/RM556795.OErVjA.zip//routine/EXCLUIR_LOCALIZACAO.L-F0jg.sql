create PROCEDURE Excluir_Localizacao (
    p_id_localizacao IN INTEGER
) AS
BEGIN
    DELETE FROM Localizacao
    WHERE id_localizacao = p_id_localizacao;
END;
/

