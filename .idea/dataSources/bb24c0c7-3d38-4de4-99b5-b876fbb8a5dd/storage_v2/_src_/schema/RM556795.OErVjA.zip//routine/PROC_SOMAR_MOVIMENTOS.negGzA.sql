create PROCEDURE proc_somar_movimentos IS
  CURSOR c_mov IS
    SELECT agencia, conta, valor
    FROM fato_movimentacoes
    ORDER BY agencia, conta;

  v_agencia_curr  fato_movimentacoes.agencia%TYPE := NULL;
  v_conta_curr    fato_movimentacoes.conta%TYPE := NULL;
  v_valor_corr    NUMBER := 0;
  v_subtotal_ag   NUMBER := 0;
  v_total_geral   NUMBER := 0;
  v_exists        BOOLEAN := FALSE;

  -- exceções
  ex_no_rows EXCEPTION;
  -- variáveis temporárias para leitura
  v_agencia_prev  fato_movimentacoes.agencia%TYPE := NULL;
  v_conta_prev    fato_movimentacoes.conta%TYPE := NULL;
  v_soma_conta    NUMBER := 0;
BEGIN
  OPEN c_mov;
  FETCH c_mov INTO v_agencia_curr, v_conta_curr, v_valor_corr;
  IF c_mov%NOTFOUND THEN
    CLOSE c_mov;
    RAISE ex_no_rows;
  ELSE
    -- inicializa variáveis a partir da primeira linha
    v_subtotal_ag := 0;
    v_total_geral := 0;
    v_exists := TRUE;

    -- reinicia cursor para percorrer desde o início ordenado
    CLOSE c_mov;
    OPEN c_mov;
  END IF;

  LOOP
    FETCH c_mov INTO v_agencia_curr, v_conta_curr, v_valor_corr;
    EXIT WHEN c_mov%NOTFOUND;

    -- primeiro loop: se mudou de (agencia, conta), imprimir acumulado antigo
    IF v_agencia_prev IS NULL THEN
      -- primeira entrada
      v_agencia_prev := v_agencia_curr;
      v_conta_prev := v_conta_curr;
      v_soma_conta := v_valor_corr;
    ELSIF v_agencia_curr = v_agencia_prev AND v_conta_curr = v_conta_prev THEN
      v_soma_conta := v_soma_conta + v_valor_corr;
    ELSE
      -- houve mudança de conta (pode ser mudança de agencia também)
      -- imprime a linha da combinação anterior
      DBMS_OUTPUT.PUT_LINE(RPAD(' ',0) || 'AGENCIA: ' || NVL(v_agencia_prev,'NULL') ||
                           ' | CONTA: ' || NVL(v_conta_prev,'NULL') ||
                           ' | SOMA: ' || TO_CHAR(v_soma_conta,'FM99999990.00'));
      -- acumula subtotal e total
      v_subtotal_ag := v_subtotal_ag + v_soma_conta;
      v_total_geral := v_total_geral + v_soma_conta;

      -- se mudou de agência (ou não), tratar subtotais quando apropriado
      IF v_agencia_curr <> v_agencia_prev THEN
        -- imprime subtotal da agencia anterior (linha com conta nula)
        DBMS_OUTPUT.PUT_LINE(RPAD(' ',0) || 'AGENCIA: ' || NVL(v_agencia_prev,'NULL') || ' | CONTA: ' || 'NULL' || ' | SUBTOTAL: ' || TO_CHAR(v_subtotal_ag,'FM99999990.00'));
        -- reset subtotal para nova agência
        v_subtotal_ag := 0;
      END IF;

      -- inicializa para nova conta
      v_agencia_prev := v_agencia_curr;
      v_conta_prev := v_conta_curr;
      v_soma_conta := v_valor_corr;
    END IF;

  END LOOP;

  -- Após sair do loop, imprimir o último agrupamento pendente
  IF v_agencia_prev IS NOT NULL THEN
    DBMS_OUTPUT.PUT_LINE(RPAD(' ',0) || 'AGENCIA: ' || NVL(v_agencia_prev,'NULL') ||
                         ' | CONTA: ' || NVL(v_conta_prev,'NULL') ||
                         ' | SOMA: ' || TO_CHAR(v_soma_conta,'FM99999990.00'));
    v_subtotal_ag := v_subtotal_ag + v_soma_conta;
    v_total_geral := v_total_geral + v_soma_conta;

    -- imprime subtotal da última agencia
    DBMS_OUTPUT.PUT_LINE(RPAD(' ',0) || 'AGENCIA: ' || NVL(v_agencia_prev,'NULL') || ' | CONTA: ' || 'NULL' || ' | SUBTOTAL: ' || TO_CHAR(v_subtotal_ag,'FM99999990.00'));
  END IF;

  -- imprime total geral (linha com agencia nula)
  DBMS_OUTPUT.PUT_LINE(RPAD(' ',0) || 'AGENCIA: ' || 'NULL' || ' | CONTA: ' || 'NULL' || ' | TOTAL_GERAL: ' || TO_CHAR(v_total_geral,'FM99999990.00'));

  CLOSE c_mov;
EXCEPTION
  WHEN ex_no_rows THEN
    DBMS_OUTPUT.PUT_LINE('{"info":"NO_DATA","message":"Nenhuma movimentacao encontrada."}');
  WHEN ZERO_DIVIDE THEN
    DBMS_OUTPUT.PUT_LINE('{"error":"ZERO_DIVIDE","message":"Erro aritmético inesperado."}');
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('{"error":"UNEXPECTED","message":"' || SUBSTR(SQLERRM,1,200) || '"}');
    IF c_mov%ISOPEN THEN
      CLOSE c_mov;
    END IF;
END proc_somar_movimentos;
/

