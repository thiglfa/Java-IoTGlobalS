create PACKAGE BODY pkg_trg_usuario AS

  PROCEDURE before_insert_usuario(
    p_criado_em IN OUT DATE,
    p_senha     IN VARCHAR2
  ) IS
    v_result VARCHAR2(200);
  BEGIN
    -- Popula data de criaÃ§Ã£o se nÃ£o informada
    IF p_criado_em IS NULL THEN
      p_criado_em := SYSDATE;
    END IF;

    -- Valida senha usando funÃ§Ã£o do pacote de validaÃ§Ã£o
    v_result := pkg_validacao_senha.valida_senha(p_senha);

    IF v_result <> 'OK' THEN
      -- Impede o insert com mensagem apropriada
      RAISE_APPLICATION_ERROR(-20002, 'Senha invÃ¡lida: ' || v_result);
    END IF;

  EXCEPTION
    WHEN VALUE_ERROR THEN
      RAISE_APPLICATION_ERROR(-20003, 'Erro de valor ao inserir usuÃ¡rio.');
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20004, 'Erro desconhecido na trigger de usuÃ¡rio: ' || SUBSTR(SQLERRM, 1, 200));
  END before_insert_usuario;

END pkg_trg_usuario;
/

