create PROCEDURE Excluir_Categoria (
    p_id_categoria IN INTEGER
) AS
BEGIN
    DELETE FROM Categoria
    WHERE id_categoria = p_id_categoria;
END;
/

