create trigger TRG_VALIDAR_NOME_NAVE
    before insert or update
    on NAVES
    for each row
BEGIN
    IF :NEW.nome IS NULL OR LENGTH(:NEW.nome) < 3 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Nome de nave inválido para cadastro.');
    ELSE dbms_output.put_line('Nome válido!');

    END IF;
END;
/

