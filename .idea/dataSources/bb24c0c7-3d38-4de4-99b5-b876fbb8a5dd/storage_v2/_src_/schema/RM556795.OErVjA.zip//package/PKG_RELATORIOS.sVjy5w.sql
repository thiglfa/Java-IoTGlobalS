create PACKAGE pkg_relatorios AS
  PROCEDURE proc_join_to_json;
END pkg_relatorios;
/

