create FUNCTION Total_Denuncias_Por_Cidade (
    p_cidade IN VARCHAR2
) RETURN INTEGER AS
    v_total INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_total
    FROM Denuncia d
    JOIN Localizacao l ON d.id_localizacao = l.id_localizacao
    WHERE LOWER(l.cidade) = LOWER(p_cidade);

    RETURN v_total;
END;
/

