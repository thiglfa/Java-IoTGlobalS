create view V_CONSULTA_DIASEMANA_RM556795_RM558154 as
SELECT 
    TO_CHAR(dt_hr_consulta, 'D') AS numero_dia_semana,
    TO_CHAR(dt_hr_consulta, 'Day') AS nome_dia_semana,
    TO_CHAR(dt_hr_consulta, 'HH24') AS hora_consulta,
    COUNT(*) AS quantidade_consultas
FROM 
    t_rhstu_consulta
GROUP BY 
    TO_CHAR(dt_hr_consulta, 'D'),
    TO_CHAR(dt_hr_consulta, 'Day'),
    TO_CHAR(dt_hr_consulta, 'HH24')
ORDER BY 
    numero_dia_semana,
    hora_consulta
/

