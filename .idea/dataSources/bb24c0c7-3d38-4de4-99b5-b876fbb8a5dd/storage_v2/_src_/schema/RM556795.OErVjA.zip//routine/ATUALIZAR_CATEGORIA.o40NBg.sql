create PROCEDURE Atualizar_Categoria (
    p_id_categoria IN INTEGER,
    p_nome         IN VARCHAR2
) AS
BEGIN
    UPDATE Categoria
    SET nome = p_nome
    WHERE id_categoria = p_id_categoria;
END;
/

