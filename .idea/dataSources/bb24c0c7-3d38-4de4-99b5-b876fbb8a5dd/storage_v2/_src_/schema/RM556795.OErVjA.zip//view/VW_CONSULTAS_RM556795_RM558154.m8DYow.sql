create view VW_CONSULTAS_RM556795_RM558154 as
SELECT 
    c.nr_consulta,
    p.nm_paciente,
    p.nr_cpf,
    e.ds_email,
    c.dt_hr_consulta,
    c.vl_consulta
FROM 
    t_rhstu_consulta c
JOIN 
    t_rhstu_paciente p ON c.id_paciente = p.id_paciente
JOIN 
    t_rhstu_email_paciente e ON p.id_paciente = e.id_paciente
WHERE 
    e.st_email = 'A'
/

