create PROCEDURE Inserir_Localizacao (
    p_latitude  IN FLOAT,
    p_longitude IN FLOAT,
    p_cidade    IN VARCHAR2,
    p_estado    IN VARCHAR2,
    p_pais      IN VARCHAR2
) AS
BEGIN
    INSERT INTO Localizacao (id_localizacao, latitude, longitude, cidade, estado, pais)
    VALUES (Localizacao_seq.NEXTVAL, p_latitude, p_longitude, p_cidade, p_estado, p_pais);
END;
/

