create PACKAGE pkg_trg_auditoria_usuario AS
  PROCEDURE registrar_auditoria(
    p_operacao     VARCHAR2,
    p_usuario_banco VARCHAR2,
    p_old_id       usuario_mottu.id%TYPE,
    p_old_nome     usuario_mottu.nome%TYPE,
    p_old_email    usuario_mottu.email%TYPE,
    p_old_senha    usuario_mottu.senha%TYPE,
    p_old_criado   usuario_mottu.criado_em%TYPE,
    p_new_id       usuario_mottu.id%TYPE,
    p_new_nome     usuario_mottu.nome%TYPE,
    p_new_email    usuario_mottu.email%TYPE,
    p_new_senha    usuario_mottu.senha%TYPE,
    p_new_criado   usuario_mottu.criado_em%TYPE
  );
END pkg_trg_auditoria_usuario;
/

