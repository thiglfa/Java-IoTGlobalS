create PACKAGE BODY pkg_starwars AS
PROCEDURE registrar_batalha(p_nome_batalha VARCHAR2, p_data DATE)
IS
BEGIN
INSERT INTO batalhas (nome_batalha, data_batalha) VALUES (p_nome_batalha, p_data);
END;

FUNCTION frota_por_batalha(p_id_batalha IN Batalhas_naves.id_batalha%type) RETURN NUMBER IS
    v_frota_total NUMBER;
BEGIN
    SELECT SUM(b.quantidade)
    INTO v_frota_total
    FROM batalhas_naves b
    WHERE b.id_batalha = p_id_batalha;
    RETURN v_frota_total;
END;
END pkg_starwars;
/

