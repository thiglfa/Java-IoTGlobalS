create PACKAGE pkg_validacao_senha AS
  FUNCTION valida_senha(p_senha IN VARCHAR2) RETURN VARCHAR2;
END pkg_validacao_senha;
/

