create PROCEDURE Atualizar_Denuncia (
    p_id_denuncia    IN INTEGER,
    p_descricao      IN VARCHAR2,
    p_data           IN TIMESTAMP,
    p_id_categoria   IN INTEGER,
    p_id_usuario     IN INTEGER,
    p_id_localizacao IN INTEGER
) AS
BEGIN
    UPDATE Denuncia
    SET descricao      = p_descricao,
        data           = p_data,
        id_categoria   = p_id_categoria,
        id_usuario     = p_id_usuario,
        id_localizacao = p_id_localizacao
    WHERE id_denuncia = p_id_denuncia;
END;
/

