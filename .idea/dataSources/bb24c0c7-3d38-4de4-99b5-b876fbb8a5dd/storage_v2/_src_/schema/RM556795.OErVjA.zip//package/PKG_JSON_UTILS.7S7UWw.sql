create PACKAGE pkg_json_utils AS
  -- FunÃ§Ã£o para gerar JSON
  FUNCTION json_manual( p_id IN NUMBER, p_usuario IN VARCHAR2, p_email IN VARCHAR2, 
                        p_placa IN VARCHAR2, p_modelo IN VARCHAR2, p_status IN VARCHAR2) 
  RETURN VARCHAR2;
END pkg_json_utils;
/

