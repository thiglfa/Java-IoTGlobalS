create PACKAGE BODY pkg_relatorios AS

  PROCEDURE proc_join_to_json IS
    CURSOR c_join IS
      SELECT u.id       AS user_id,
             u.nome     AS user_nome,
             u.email    AS user_email,
             m.placa    AS m_placa,
             m.modelo   AS m_modelo,
             m.status   AS m_status
      FROM usuario_mottu u
      JOIN moto_mottu m ON m.usuario_id = u.id
      ORDER BY u.id, m.id;

    v_row c_join%ROWTYPE;
    v_json VARCHAR2(4000);

    -- exceÃ§Ãµes personalizadas
    ex_no_rows EXCEPTION;
    ex_other EXCEPTION;

  BEGIN
    OPEN c_join;
    FETCH c_join INTO v_row;
    IF c_join%NOTFOUND THEN
      CLOSE c_join;
      RAISE ex_no_rows;
    ELSE
      -- volta pro inÃ­cio para percorrer normalmente
      CLOSE c_join;
      OPEN c_join;
    END IF;

    LOOP
      FETCH c_join INTO v_row;
      EXIT WHEN c_join%NOTFOUND;
      BEGIN
        v_json := json_manual(
                    v_row.user_id,
                    v_row.user_nome,
                    v_row.user_email,
                    NVL(v_row.m_placa, ''),
                    NVL(v_row.m_modelo, ''),
                    NVL(v_row.m_status, '')
                  );

        -- exibe como string JSON (cada linha)
        DBMS_OUTPUT.PUT_LINE(v_json);

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(
            '{"error":"ROW_PROCESSING_ERROR","message":"' ||
            SUBSTR(SQLERRM, 1, 200) || '"}'
          );
          -- continua o processamento das demais linhas
      END;
    END LOOP;
    CLOSE c_join;

  EXCEPTION
    WHEN ex_no_rows THEN
      DBMS_OUTPUT.PUT_LINE('{"info":"NO_DATA","message":"Nenhuma linha encontrada no join."}');
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('{"error":"NO_DATA_FOUND"}');
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('{"error":"UNEXPECTED","message":"' || SUBSTR(SQLERRM, 1, 200) || '"}');
  END proc_join_to_json;

END pkg_relatorios;
/

