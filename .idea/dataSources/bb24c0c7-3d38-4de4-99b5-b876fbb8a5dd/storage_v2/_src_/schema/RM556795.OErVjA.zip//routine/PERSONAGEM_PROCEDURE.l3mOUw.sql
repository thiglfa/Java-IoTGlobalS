create PROCEDURE Personagem_Procedure
IS
BEGIN
INSERT INTO personagens (nome, planeta_origem) VALUES ('Anakin Skywalker', 'Tatooine');
INSERT INTO personagens (nome, planeta_origem) VALUES ('Rey', 'Tatooine');
END Personagem_Procedure;
/

