create PROCEDURE Excluir_Usuario (
    p_id_usuario IN INTEGER
) AS
BEGIN
    DELETE FROM Usuario
    WHERE id_usuario = p_id_usuario;
END;
/

