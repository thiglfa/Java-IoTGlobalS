create PACKAGE pkg_trg_usuario AS
  -- Procedimento auxiliar chamado pela trigger
  PROCEDURE before_insert_usuario(
    p_criado_em IN OUT DATE,
    p_senha     IN VARCHAR2
  );
END pkg_trg_usuario;
/

