create PROCEDURE Inserir_Usuario (
    p_nome   IN VARCHAR2,
    p_email  IN VARCHAR2,
    p_senha  IN VARCHAR2
) AS
BEGIN
    INSERT INTO Usuario (id_usuario, nome, email, senha)
    VALUES (Usuario_seq.NEXTVAL, p_nome, p_email, p_senha);
END;
/

