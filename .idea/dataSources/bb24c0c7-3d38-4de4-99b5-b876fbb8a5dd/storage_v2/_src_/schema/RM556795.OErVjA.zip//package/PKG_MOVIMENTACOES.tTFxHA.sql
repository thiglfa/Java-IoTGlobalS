create PACKAGE pkg_movimentacoes AS
  PROCEDURE proc_somar_movimentos;
END pkg_movimentacoes;
/

