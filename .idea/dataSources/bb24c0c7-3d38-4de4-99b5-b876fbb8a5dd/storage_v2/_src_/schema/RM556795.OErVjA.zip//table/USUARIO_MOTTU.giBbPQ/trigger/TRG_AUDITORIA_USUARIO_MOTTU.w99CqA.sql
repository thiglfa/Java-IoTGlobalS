create trigger TRG_AUDITORIA_USUARIO_MOTTU
    after insert or update or delete
    on USUARIO_MOTTU
    for each row
BEGIN
  pkg_trg_auditoria_usuario.registrar_auditoria(
    CASE
      WHEN INSERTING THEN 'INSERT'
      WHEN UPDATING  THEN 'UPDATE'
      WHEN DELETING  THEN 'DELETE'
    END,
    USER,
    :OLD.id, :OLD.nome, :OLD.email, :OLD.senha, :OLD.criado_em,
    :NEW.id, :NEW.nome, :NEW.email, :NEW.senha, :NEW.criado_em
  );
END;
/

