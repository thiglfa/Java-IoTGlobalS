create trigger TRG_BEFORE_INSERT_USUARIO
    before insert
    on USUARIO_MOTTU
    for each row
BEGIN
  pkg_trg_usuario.before_insert_usuario(:NEW.criado_em, :NEW.senha);
END;
/

