create FUNCTION Denuncias_Por_Categoria (
    p_categoria_id IN INTEGER
) RETURN INTEGER AS
    v_total INTEGER;
BEGIN
    SELECT COUNT(*)
    INTO v_total
    FROM Denuncia
    WHERE id_categoria = p_categoria_id;

    RETURN v_total;
END;
/

