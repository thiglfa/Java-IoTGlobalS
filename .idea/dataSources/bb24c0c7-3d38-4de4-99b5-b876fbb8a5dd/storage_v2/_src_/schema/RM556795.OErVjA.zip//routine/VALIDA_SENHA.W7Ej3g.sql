create FUNCTION valida_senha(p_senha IN VARCHAR2) RETURN VARCHAR2 IS
  ex_too_short EXCEPTION;
  ex_no_digit  EXCEPTION;
  ex_no_upper  EXCEPTION;
  v_len NUMBER;
  v_has_digit NUMBER := 0;
  v_has_upper NUMBER := 0;
BEGIN
  IF p_senha IS NULL THEN
    RAISE ex_too_short;
  END IF;

  v_len := LENGTH(p_senha);
  IF v_len < 8 THEN
    RAISE ex_too_short;
  END IF;

  -- Verifica se tem dígito
  FOR i IN 1..v_len LOOP
    IF SUBSTR(p_senha, i, 1) BETWEEN '0' AND '9' THEN
      v_has_digit := 1;
      EXIT;
    END IF;
  END LOOP;
  IF v_has_digit = 0 THEN
    RAISE ex_no_digit;
  END IF;

  -- Verifica se tem letra maiúscula
  FOR i IN 1..v_len LOOP
    IF SUBSTR(p_senha, i, 1) BETWEEN 'A' AND 'Z' THEN
      v_has_upper := 1;
      EXIT;
    END IF;
  END LOOP;
  IF v_has_upper = 0 THEN
    RAISE ex_no_upper;
  END IF;

  RETURN 'OK';

EXCEPTION
  WHEN ex_too_short THEN
    RETURN 'ERROR:TOO_SHORT';
  WHEN ex_no_digit THEN
    RETURN 'ERROR:NO_DIGIT';
  WHEN ex_no_upper THEN
    RETURN 'ERROR:NO_UPPER';
  WHEN OTHERS THEN
    RETURN 'ERROR:UNEXPECTED:' || SUBSTR(SQLERRM,1,200);
END valida_senha;
/

