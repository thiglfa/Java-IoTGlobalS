create PACKAGE pkg_starwars AS
    PROCEDURE registrar_batalha (p_nome_batalha VARCHAR2, p_data DATE);
    FUNCTION frota_por_batalha(p_id_batalha IN Batalhas_naves.id_batalha%type) RETURN NUMBER;
    END pkg_starwars;
/

