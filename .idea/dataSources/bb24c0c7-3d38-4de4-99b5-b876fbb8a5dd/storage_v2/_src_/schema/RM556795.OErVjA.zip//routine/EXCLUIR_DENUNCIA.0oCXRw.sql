create PROCEDURE Excluir_Denuncia (
    p_id_denuncia IN INTEGER
) AS
BEGIN
    DELETE FROM Denuncia
    WHERE id_denuncia = p_id_denuncia;
END;
/

