create PACKAGE BODY pkg_trg_auditoria_usuario AS
  PROCEDURE registrar_auditoria(
    p_operacao     VARCHAR2,
    p_usuario_banco VARCHAR2,
    p_old_id       usuario_mottu.id%TYPE,
    p_old_nome     usuario_mottu.nome%TYPE,
    p_old_email    usuario_mottu.email%TYPE,
    p_old_senha    usuario_mottu.senha%TYPE,
    p_old_criado   usuario_mottu.criado_em%TYPE,
    p_new_id       usuario_mottu.id%TYPE,
    p_new_nome     usuario_mottu.nome%TYPE,
    p_new_email    usuario_mottu.email%TYPE,
    p_new_senha    usuario_mottu.senha%TYPE,
    p_new_criado   usuario_mottu.criado_em%TYPE
  ) IS
    v_valor_antigo CLOB;
    v_valor_novo   CLOB;
  BEGIN
    -- Monta valores antigos
    IF p_operacao IN ('UPDATE', 'DELETE') THEN
      v_valor_antigo := 'ID=' || p_old_id ||
                        ', Nome=' || NVL(p_old_nome, '[NULL]') ||
                        ', Email=' || NVL(p_old_email, '[NULL]') ||
                        ', Senha=' || NVL(p_old_senha, '[NULL]') ||
                        ', Criado_em=' || NVL(TO_CHAR(p_old_criado, 'DD/MM/YYYY HH24:MI:SS'), '[NULL]');
    END IF;

    -- Monta valores novos
    IF p_operacao IN ('INSERT', 'UPDATE') THEN
      v_valor_novo := 'ID=' || p_new_id ||
                      ', Nome=' || NVL(p_new_nome, '[NULL]') ||
                      ', Email=' || NVL(p_new_email, '[NULL]') ||
                      ', Senha=' || NVL(p_new_senha, '[NULL]') ||
                      ', Criado_em=' || NVL(TO_CHAR(p_new_criado, 'DD/MM/YYYY HH24:MI:SS'), '[NULL]');
    END IF;

    -- Grava auditoria
    INSERT INTO auditoria_usuario_mottu (usuario_banco, operacao, data_hora, valor_antigo, valor_novo)
    VALUES (p_usuario_banco, p_operacao, SYSDATE, v_valor_antigo, v_valor_novo);
  END registrar_auditoria;
END pkg_trg_auditoria_usuario;
/

