create PROCEDURE Atualizar_Localizacao (
    p_id_localizacao IN INTEGER,
    p_latitude       IN FLOAT,
    p_longitude      IN FLOAT,
    p_cidade         IN VARCHAR2,
    p_estado         IN VARCHAR2,
    p_pais           IN VARCHAR2
) AS
BEGIN
    UPDATE Localizacao
    SET latitude  = p_latitude,
        longitude = p_longitude,
        cidade    = p_cidade,
        estado    = p_estado,
        pais      = p_pais
    WHERE id_localizacao = p_id_localizacao;
END;
/

