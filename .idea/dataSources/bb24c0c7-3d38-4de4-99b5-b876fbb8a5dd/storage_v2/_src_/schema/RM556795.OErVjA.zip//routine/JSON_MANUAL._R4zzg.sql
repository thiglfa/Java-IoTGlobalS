create FUNCTION json_manual( p_id IN NUMBER, p_usuario IN VARCHAR2, p_email IN VARCHAR2, p_placa IN VARCHAR2,
  p_modelo  IN VARCHAR2, p_status  IN VARCHAR2
) RETURN VARCHAR2 IS
  v_json VARCHAR2(4000);
  -- exceções personalizadas
  ex_null_input EXCEPTION;
  ex_too_long   EXCEPTION;
  ex_invalid_chr EXCEPTION;
  PRAGMA EXCEPTION_INIT(ex_invalid_chr, -20001);
BEGIN
  -- 1) validações (podemos lançar exceções customizadas)
  IF p_usuario IS NULL OR p_email IS NULL THEN
    RAISE ex_null_input;
  END IF;

  IF LENGTH(p_usuario) > 100 OR LENGTH(p_modelo) > 100 THEN
    RAISE ex_too_long;
  END IF;

  -- checar caracter inválido simples (por exemplo, caractere de controle)
  IF INSTR(p_usuario, CHR(0)) > 0 THEN
    RAISE_APPLICATION_ERROR(-20001, 'Caractere inválido encontrado no nome do usuário.');
  END IF;

  -- montar JSON manualmente (escapando aspas internas simples)
  -- substitui aspas duplas por aspas escapadas (\"), considerando limites
  v_json := '{' ||
            '"id":' || TO_CHAR(p_id) || ',' ||
            '"usuario":"' || REPLACE(p_usuario, '"', '\"') || '",' ||
            '"email":"'   || REPLACE(p_email, '"', '\"')   || '",' ||
            '"placa":"'   || REPLACE(p_placa, '"', '\"')   || '",' ||
            '"modelo":"'  || REPLACE(p_modelo, '"', '\"')  || '",' ||
            '"status":"'  || REPLACE(p_status, '"', '\"')  || '"' ||
            '}';
  RETURN v_json;

EXCEPTION
  WHEN ex_null_input THEN
    RETURN '{"error":"NULL_INPUT","message":"Nome ou email nulo."}';
  WHEN ex_too_long THEN
    RETURN '{"error":"VALUE_TOO_LONG","message":"Campo ultrapassa tamanho máximo permitido."}';
  WHEN OTHERS THEN
    -- retorno de erro padronizado (na prática poderia logar)
    RETURN '{"error":"UNEXPECTED","message":"' || SUBSTR(SQLERRM,1,200) || '"}';
END json_manual;
/

