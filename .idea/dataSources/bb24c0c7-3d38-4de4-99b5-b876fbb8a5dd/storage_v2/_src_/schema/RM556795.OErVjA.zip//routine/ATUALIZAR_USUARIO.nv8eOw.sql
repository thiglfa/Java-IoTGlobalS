create PROCEDURE Atualizar_Usuario (
    p_id_usuario IN INTEGER,
    p_nome       IN VARCHAR2,
    p_email      IN VARCHAR2,
    p_senha      IN VARCHAR2
) AS
BEGIN
    UPDATE Usuario
    SET nome  = p_nome,
        email = p_email,
        senha = p_senha
    WHERE id_usuario = p_id_usuario;
END;
/

