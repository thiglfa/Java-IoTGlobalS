create PROCEDURE Inserir_Denuncia (
    p_descricao      IN VARCHAR2,
    p_data           IN TIMESTAMP,
    p_id_categoria   IN INTEGER,
    p_id_usuario     IN INTEGER,
    p_id_localizacao IN INTEGER
) AS
BEGIN
    INSERT INTO Denuncia (
        id_denuncia, descricao, data, id_categoria, id_usuario, id_localizacao
    )
    VALUES (
        Denuncia_seq.NEXTVAL, p_descricao, p_data, p_id_categoria, p_id_usuario, p_id_localizacao
    );
END;
/

