create view V_TOPN_MEDIC_RM556795_RM558154 as
SELECT 
    m.id_medicamento AS codigo_medicamento,
    m.nm_medicamento AS nome_medicamento,
    SUM(p.qt_medicamento) AS QTDE_Medicamento
FROM 
    t_rhstu_prescicao_medica p
JOIN 
    t_rhstu_medicamento m ON p.id_medicamento = m.id_medicamento
GROUP BY 
    m.id_medicamento, 
    m.nm_medicamento
ORDER BY 
    QTDE_Medicamento DESC
/

