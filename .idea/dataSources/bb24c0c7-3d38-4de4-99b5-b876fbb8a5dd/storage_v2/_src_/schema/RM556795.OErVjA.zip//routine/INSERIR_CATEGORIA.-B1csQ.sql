create PROCEDURE Inserir_Categoria (
    p_nome IN VARCHAR2
) AS
BEGIN
    INSERT INTO Categoria (id_categoria, nome)
    VALUES (Categoria_seq.NEXTVAL, p_nome);
END;
/

