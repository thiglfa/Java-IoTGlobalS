create FUNCTION qtde_naves_batalha(p_id_batalha IN Batalhas_naves.id_batalha%type) RETURN NUMBER IS
    v_total NUMBER;
BEGIN
    SELECT SUM(b.quantidade)
    INTO v_total
    FROM batalhas_naves b
    WHERE b.id_batalha = p_id_batalha;
    RETURN v_total;
END;
/

